
public class Customer {
    
    public void selectPayment (Shop s, PaymentType pt){
        
    System.out.print( s.getName() + " :: ");
    s.PaymentChange(pt);
                
    }
    
}
