
public class ShopMain {

    public static void main(String[] args) {
        
        Customer c = new Customer ();
        
        Shop s1 = new Shop("X", new VisaCard());
        Shop s2 = new Shop("Y", new Bkash());
        Shop s3 = new Shop("Z", new CashOnDelivery());
        
        c.selectPayment( s1, new CashOnDelivery() );
        c.selectPayment( s2, new VisaCard() );
        c.selectPayment( s3, new Bkash() );
		
    }
    
}
