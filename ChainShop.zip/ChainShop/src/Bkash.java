
public class Bkash implements PaymentType {
    
    public void payment(){
        
        System.out.println("Payment Type: BKASH");
    }
}
