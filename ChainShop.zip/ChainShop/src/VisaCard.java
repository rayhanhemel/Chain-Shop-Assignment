
public class VisaCard implements PaymentType {
    
    public void payment (){
        
        System.out.println("Payment type: Visa Card");
        
    }
    
}
