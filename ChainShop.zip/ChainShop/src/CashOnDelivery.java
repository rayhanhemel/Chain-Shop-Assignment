
public class CashOnDelivery implements PaymentType {
    
    public void payment(){
        
        System.out.println("Payment Type: Cash on Delivery");
    }
}
