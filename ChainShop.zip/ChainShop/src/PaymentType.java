
public interface PaymentType {
    
    public void payment();
    
}
