
public class Shop {
    
    private String payemntName;
    private PaymentType PT;

    public Shop(String name, PaymentType paymentstyle) {
        this.payemntName = name;
        this.PT = paymentstyle;
        System.out.println(name+ " " + paymentstyle.getClass() + " ");
    }

    public void PaymentChange(PaymentType pt) {
        PT = pt;
        PT.payment();
    }
    
    public String getName(){
		return payemntName;
	}
    
}
